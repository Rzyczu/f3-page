<?php
// Plik: /inc/global/forms.php

function handle_contact_form() {
    $name = isset($_POST['name']) ? sanitize_text_field($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $message = isset($_POST['message']) ? sanitize_textarea_field($_POST['message']) : '';

    if (!is_email($email)) {
        wp_die('Niepoprawny adres e-mail.');
    }

    wp_mail(
        get_option('admin_email'),
        'Nowa wiadomość kontaktowa',
        sprintf("Imię: %s\nE-mail: %s\nWiadomość:\n%s", $name, $email, $message)
    );

    wp_safe_redirect(home_url('/thank-you'));
    exit;
}
add_action('admin_post_nopriv_contact_form', 'handle_contact_form');
add_action('admin_post_contact_form', 'handle_contact_form');

function sanitize_form_data($post_data) {
    $sanitized_data = array(
        'name' => isset($post_data['name']) ? sanitize_text_field($post_data['name']) : '',
        'email' => isset($post_data['email']) ? sanitize_email($post_data['email']) : '',
        'message' => isset($post_data['message']) ? sanitize_textarea_field($post_data['message']) : '',
    );

    if (!is_email($sanitized_data['email'])) {
        wp_die('Niepoprawny adres e-mail.');
    }

    return $sanitized_data;
}

function validate_post_data($data) {
    if (empty($data)) {
        wp_send_json_error('Brak wymaganych danych.');
    }
}