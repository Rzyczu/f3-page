<section class="relative mt-24 text-white bg-primary">
            <div class="container items-start py-24 mx-auto max-md:flex-col-reverse">
                <div class="">
                    <h2 class="mb-8">Napisz do nas</h2>
                    <form>
                        <label for="name">imie i nazwisko</label><br>
                        <input class="input" placeholder="imie i nazwisko" type="text" id="name" name="name"><br>
                        <label for="mail">e-mail</label><br>
                        <input class="input" placeholder="e-mail" type="text" id="mail" name="mail"><br>
                        <label for="message">wiadomość</label><br>
                        <textarea class="input" placeholder="tu wpisz swoją wiadomość" id="message"
                            name="message"></textarea><br>
                        <input class="float-right cursor-pointer" type="submit" value="Wyślij >">

                    </form>
                </div>
            </div>
        </section>