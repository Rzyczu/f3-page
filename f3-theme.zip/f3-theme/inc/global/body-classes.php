<?php

// function add_bg_white_to_body_class($classes) {
//     $classes[] = 'bg-white';
//     return $classes;
// }
// add_filter('body_class', 'add_bg_white_to_body_class');