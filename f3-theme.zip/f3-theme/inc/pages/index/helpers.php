<?php

// function flush_rewrite_rules_on_init() {
//     flush_rewrite_rules();
// }
// add_action('init', 'flush_rewrite_rules_on_init');
