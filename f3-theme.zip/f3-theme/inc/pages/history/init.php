<?php

// Customizer
require_once __DIR__ . '/customizer/panel.php';

// Meta
require_once __DIR__ . '/meta/history-meta.php';

// CPT
require_once __DIR__ . '/post-types/history-entry.php';

// Setup Theme
require_once __DIR__ . '/setup/theme.php';
