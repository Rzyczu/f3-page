<?php
// File: 404.php
wp_redirect(home_url());
exit;
?>
